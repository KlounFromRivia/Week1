﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MDA_Task_4
{
    public class Program
    {
        public static string[] death =
                              {"██    ██   ██████   ██    ██      ███████   ████████  ████████  ███████ ",
                               "██    ██  ██    ██  ██    ██      ██    ██     ██     ██        ██    ██",
                               " ██  ██   ██    ██  ██    ██      ██    ██     ██     ██        ██    ██",
                               "   ██     ██    ██  ██    ██      ██    ██     ██     ████████  ██    ██",
                               "   ██     ██    ██  ██    ██      ██    ██     ██     ██        ██    ██",
                               "   ██     ██    ██  ██    ██      ██    ██     ██     ██        ██    ██",
                               "   ██      ██████     ████        ███████   ████████  ████████  ███████ "};

        public static string[] win =
                              {"██    ██   ██████   ██    ██      █  ██  █  ████████  ███    █",
                               "██    ██  ██    ██  ██    ██      █  ██  █     ██     ██ █  ██",
                               " ██  ██   ██    ██  ██    ██      █  ██  █     ██     ██ █  ██",
                               "   ██     ██    ██  ██    ██      █  ██  █     ██     ██  █ ██",
                               "   ██     ██    ██  ██    ██      █  ██  █     ██     ██  █ ██",
                               "   ██     ██    ██  ██    ██      █  ██  █     ██     ██  █ ██",
                               "   ██      ██████     ████         ██████   ████████  █    ███"};
        static void Main(string[] args)
        {
            Random rnd = new Random();
            //здоровье игроков
            int healthPlayer = rnd.Next(400, 601);
            int healthBoss = rnd.Next(600, 1200);

            //игровой акт и ход игрока
            int numberAct = 1;
            int gameHod = 2;

            int[] health = new int[] { healthPlayer, healthBoss };

            //огненный шар и поджег босса
            int fire = 10;
            int toBurn = 0;

            //щит и откат щита
            int shield = 0;
            int otkatShield = 0;

            //лечение
            int heal = 300;

            //виктима
            int victima = 0;

            Console.WriteLine("Игра - Победи БОССА");
            Console.WriteLine("Условия:");
            Console.WriteLine("Случайным образом выбирается игрок, делающий первый ход");
            Console.WriteLine("Величина урона, наносимого БОССОМ, для каждого хода случайна");
            Console.WriteLine("Игрок может пользоваться следующими заклинаниями:\n");
            Console.WriteLine("фаерболл - атака, может наноситься урон от 30 единиц\n"+
                "Босс воспламеняется на 5 ходов. С каждом ходом огонь наносит больше урона\n");

            Console.WriteLine("защитный круг - образовывает вокруг вас щит с прочностью в 500 единиц\n" +
                "После разбития щита, вы не сможете его использовать 3 хода\n");

            Console.WriteLine("куратио - вы увеличиваете свое здоровье на 300 единиц\n" +
                "(лечение с каждым применением становится менее эффективным)\n");

            Console.WriteLine("виктима - вы колдуете обряд на проклятье противника (теряете 1000 здоровья)\n" +
                "После применения позволяет использовать крепитус\n");

            Console.WriteLine("крепитус - проклятье, которое накладывается на противника (полное поражение противника)\n" +
                "Если перед использование не провести виктиму, то проклятие наступит на колдовавшего\n");

            Console.WriteLine("Начальное значение здоровья у игрока - " + healthPlayer + " единиц");
            Console.WriteLine("Начальное значение здоровья у БОССА - " + healthBoss + " единиц\n");


            while (healthPlayer > 0 && healthBoss > 0)
            {
                health = GameAct(health);
                healthPlayer = health[0];
                healthBoss = health[1];
            }

            //healthBoss = 0;
            //healthPlayer = 0;

            var widthX = 0;
            var heightY = 0;
            var x = 0;
            var y = 0;

            Console.ReadKey();

            if (healthPlayer <= 0)
            {
                widthX = 72;
                heightY = 7;
                x = (Console.WindowWidth / 2) - (widthX / 2);
                y = (Console.WindowHeight / 2) - (heightY / 2);

                Console.Clear();
                for (int i = 0; i < death.GetLength(0); i++)
                {
                    Console.ForegroundColor = ConsoleColor.DarkRed;
                    Console.SetCursorPosition(x, ++y);
                    Console.WriteLine(death[i]);
                }
            }
            else
            {
                widthX = 62;
                heightY = 7;
                x = (Console.WindowWidth / 2) - (widthX / 2);
                y = (Console.WindowHeight / 2) - (heightY / 2);

                Console.Clear();
                for (int i = 0; i < win.GetLength(0); i++)
                {
                    Console.SetCursorPosition(x, ++y);
                    Console.WriteLine(win[i]);
                }
            }



            Console.ReadKey();


            int[] GameAct(int[] healthPB)
            {
                string attack = "";
                Console.WriteLine("Игровой акт № - " + numberAct);
                numberAct++;


                if (gameHod == 2)
                {
                    gameHod = rnd.Next(healthPB.Length);
                }

                int damagePlayer = 0;
                int damageBoss = rnd.Next(80, 161);

                Stew();

                switch (gameHod)
                {
                    case 0:
                        Console.WriteLine("Атакует игрок");
                        gameHod++;

                        Console.Write("Введите заклинание - ");
                        attack = Console.ReadLine();

                        switch (attack.ToLower())
                        {
                            case "фаерболл":
                                damagePlayer = rnd.Next(30,51);
                                Console.WriteLine("Сила удара - "+damagePlayer);
                                healthPB[1] -= damagePlayer;
                                toBurn = 5;

                                Stew();

                                break;
                            case "защитный круг":
                                if (otkatShield > 0 && shield <=0)
                                {
                                    Console.WriteLine("Вы не смогли сколдовать щит из-за недостатки силы (осталось "+otkatShield+" хода до использования)");
                                }
                                else if(otkatShield > 0 && shield > 0)
                                {
                                    Console.WriteLine("Новый щит не появится, пока не сломается старый");
                                }
                                else
                                {
                                    Console.WriteLine("Вокруг вас образовался щит");
                                    shield = 500;
                                    otkatShield = 3;
                                }
                                break;
                            case "куратио":
                                if (heal > 0)
                                {
                                    Console.WriteLine("Вы лечитесь на " + heal + " единиц (след. лечение будет " + (heal - 50) + " единиц)");
                                    healthPB[0] += heal;
                                    heal = heal - 50;
                                }
                                else
                                {
                                    Console.WriteLine("ВЫ БОЛЬШЕ НЕ МОЖЕТЕ ЛЕЧИТЬСЯ");
                                }
                                break;
                            case "виктима":
                                if (victima == 0)
                                {
                                    Console.WriteLine("Вы совершили ритуал для наложения проклятья");
                                    healthPB[0] -= 1000;
                                    victima = 1;
                                }
                                else
                                {
                                    Console.WriteLine("Вы уже совершили ритуал");
                                }
                                break;
                            case "крепитус":
                                if (victima == 1)
                                {
                                    Console.WriteLine("Вы накладываете на противника проклятье");
                                    healthPB[1] -= 10000;
                                }
                                else
                                {
                                    Console.WriteLine("ВЫ НЕ СОВЕРШИЛИ РИТУАЛ, ПРОКЛЯТИЕ НАЛОЖИЛОСЬ НА ВАС");
                                    healthPB[0] -= 10000;
                                }
                                break;
                            default:
                                Console.WriteLine("Вы не смогли сколдовать");
                                break;
                        }

                        //перезарядка щита
                        if (otkatShield > 0 && shield <= 0)
                        {
                            otkatShield--;
                        }

                        break;
                    case 1:
                        Console.WriteLine("Атакует Босс");
                        gameHod--;

                        Console.WriteLine("Сила удара - " + damageBoss);
                        if (shield > 0)
                        {
                            shield -= damageBoss;
                            if (shield <= 0)
                            {
                                Console.WriteLine("БОСС РАЗБИЛ ЩИТ (перезарядка "+otkatShield+" хода)");
                            }
                        }
                        else
                        {
                            healthPB[0] -= damageBoss;
                        }
                        break;
                }

                //урон от огоня
                if (toBurn > 0)
                {
                    Console.WriteLine("Босс горит. Урон огня - " + fire);
                    healthPB[1] -= fire;
                    fire *= 2;
                    toBurn--;
                    if (toBurn == 0)
                    {
                        Console.WriteLine("Огонь потух");
                    }
                }
                else
                {
                    fire = 15;
                }

                //откат щита

                if (shield > 0)
                {
                    Console.WriteLine("Прочность щита - "+shield+" единиц");
                }

                if (healthPB[0] > 0)
                {
                    Console.WriteLine("Осталось здоровья у игрока - " + healthPB[0] + " единиц");
                }
                else
                {
                    Console.WriteLine("У вас кончилось здоровье");
                }
                if (healthPB[1] > 0)
                {
                    Console.WriteLine("Осталось здоровья у БОССА - " + healthPB[1] + " единиц\n");
                }
                else
                {
                    Console.WriteLine("У босса кончилось здоровье");
                }

                return healthPB;
            }

            void Stew()
            {
                if (health[1] < 400)
                {
                    if (toBurn > 0)
                    {
                        Console.WriteLine("Босс перекатывается по земле и тушит огонь.");
                    }
                    toBurn = 0;
                    fire = 15;
                }
            }
        }
    }
}
