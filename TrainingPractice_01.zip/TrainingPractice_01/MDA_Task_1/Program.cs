﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MDA_Task_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            float countGold;
            int countKristall;
            float priceKristal = 3;

            Console.WriteLine("Цена 1 кристалла стоит 3 золотых");

            do
            {
                Console.Write("Введите количество золота: ");
            }
            while (!float.TryParse(Console.ReadLine(), out countGold) || countGold < 0);

            do
            {
                do
                {
                    Console.WriteLine("Вы можете купить максимум " + Math.Round(countGold/priceKristal) +"\nСколько вы хотите купить кристаллов?");
                }
                while (!int.TryParse(Console.ReadLine(), out countKristall) || countKristall < 0);
            } while (countGold <= countKristall*priceKristal);


            countGold -= countKristall * priceKristal;

            Console.WriteLine("Осталось золота: " + countGold);
            Console.WriteLine("Количество кристаллов: " + countKristall);
            Console.ReadKey();
        }
    }
}
