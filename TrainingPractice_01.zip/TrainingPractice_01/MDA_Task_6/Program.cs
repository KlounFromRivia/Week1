﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MDA_Task_6
{
    static class Program
    {
        static string[] fios = new string[] { "Мельников Олег Олегович", "Кримов Иван Иваныч", "Бридов Никита Никитыч", "Забытова Ольга Юрьевна", "Дедова Татьяна Даниловна" };
        static string[] dolgnosts = new string[] { "Менеджер", "Зам. директора", "Директор", "Рабочий", "Рабочий" };

        static string record;
        static int index;

        static string[] menus = new string[] { "Программа 'Отдел кадров'\nВыберите операцию\n", "добавить досье", "вывести все досье"
            , "удалить досье", "поиск по фамилии","выход"};

        static void Main(string[] args)
        {
        restart:
            Console.Clear();
            foreach (string menu in menus)
                Console.WriteLine(menu);
            int num = keys();
            switch (num)
            {
                case 1: { AddRecord(); } goto restart;
                case 2: { Output(); } goto restart;
                case 3: { DeleteRecord(); } goto restart;
                case 4: { FindRecord(); } goto restart;
                case 5: { }; goto end;
            }
            Console.ReadKey();
        end:;
        }

        static T[] Append<T>(this T[] array, T item)
        {
            if (array == null)
            {
                return new T[] { item };
            }
            T[] result = new T[array.Length + 1];
            array.CopyTo(result, 0);
            result[array.Length] = item;
            return result;
        }

        static void AddRecord()
        {
            Console.Write("Введите ФИО: ");
            record = Console.ReadLine();
            fios = fios.Append(record);
            Console.Write("Введите должность: ");
            record = Console.ReadLine();
            dolgnosts = dolgnosts.Append(record);
        }

        static void Output()
        {
            if (fios.Length != 0)
            {
                Console.WriteLine("\nВывод всех досье");
                for (int i = 0; i <= fios.Length - 1; i++)
                {
                    Console.WriteLine(String.Format(" {0} | {1,-25} | {2,-15} |", i + 1, fios[i], dolgnosts[i]));
                }
            }
            else
            {
                Console.WriteLine("\nДосье отсутствуют");
            }
            Console.WriteLine("\nНажмите на любую кнопку...");
            Console.ReadKey();
        }

        static void DeleteRecord()
        {
            if (fios.Length != 0)
            {
                do
                {
                    Console.Write("\nВведите ID досье, которое нужно удалить: ");
                    if (int.TryParse(Console.ReadLine(), out index) || index > 0)
                    {
                        break;
                    }
                }
                while (true);
                for (int i = 0; i < fios.Length - 1; i++)
                {
                    fios[i] = fios[i + 1];
                    dolgnosts[i] = dolgnosts[i + 1];
                }
                Array.Resize(ref fios, fios.Length - 1);
                Array.Resize(ref dolgnosts, dolgnosts.Length - 1);
                Console.WriteLine("Запись успешно удалена");
            }
            else
            {
                Console.WriteLine("\nДосье отсутствуют");
            }
            Console.WriteLine("\nНажмите на любую кнопку...");
            Console.ReadKey();
        }

        static void FindRecord()
        {
            if (fios.Length != 0)
            {
                Console.Write("\nВведите фамилию, чтобы найти досье: ");
                record = Console.ReadLine();
                int i = 0;
                int n = 0;
                do
                {
                    string familia = fios[i];
                    if (familia.Contains(record))
                    {
                        n = 1;
                        break;
                    }
                    i++;
                } while (n == 0 || i+1 == fios.Length);
                if (n == 1)
                    Console.WriteLine(String.Format(" {0} | {1,-25} | {2,-15} |", i + 1, fios[i], dolgnosts[i]));
                else
                    Console.WriteLine("Некорректный ввод");
            }
            else
            {
                Console.WriteLine("\nДосье отсутствуют");
            }
            Console.WriteLine("\nНажмите на любую кнопку...");
            Console.ReadKey();
        }

        static void Text(int i)//Замена цвета менюшки
        {
            switch (i)
            {
                case 1:
                    Console.Clear();
                    Console.WriteLine(menus[0]);
                    Console.BackgroundColor = ConsoleColor.White;
                    Console.ForegroundColor = ConsoleColor.Black;
                    Console.WriteLine(menus[1]);
                    Console.BackgroundColor = ConsoleColor.Black;
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine(menus[2]);
                    Console.WriteLine(menus[3]);
                    Console.WriteLine(menus[4]);
                    Console.WriteLine(menus[5]);
                    break;
                case 2:
                    Console.Clear();
                    Console.WriteLine(menus[0]);
                    Console.WriteLine(menus[1]);
                    Console.BackgroundColor = ConsoleColor.White;
                    Console.ForegroundColor = ConsoleColor.Black;
                    Console.WriteLine(menus[2]);
                    Console.BackgroundColor = ConsoleColor.Black;
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine(menus[3]);
                    Console.WriteLine(menus[4]);
                    Console.WriteLine(menus[5]);
                    break;
                case 3:
                    Console.Clear();
                    Console.WriteLine(menus[0]);
                    Console.WriteLine(menus[1]);
                    Console.WriteLine(menus[2]);
                    Console.BackgroundColor = ConsoleColor.White;
                    Console.ForegroundColor = ConsoleColor.Black;
                    Console.WriteLine(menus[3]);
                    Console.BackgroundColor = ConsoleColor.Black;
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine(menus[4]);
                    Console.WriteLine(menus[5]);
                    break;
                case 4:
                    Console.Clear();
                    Console.WriteLine(menus[0]);
                    Console.WriteLine(menus[1]);
                    Console.WriteLine(menus[2]);
                    Console.WriteLine(menus[3]);
                    Console.BackgroundColor = ConsoleColor.White;
                    Console.ForegroundColor = ConsoleColor.Black;
                    Console.WriteLine(menus[4]);
                    Console.BackgroundColor = ConsoleColor.Black;
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine(menus[5]);
                    break;
                case 5:
                    Console.Clear();
                    Console.WriteLine(menus[0]);
                    Console.WriteLine(menus[1]);
                    Console.WriteLine(menus[2]);
                    Console.WriteLine(menus[3]);
                    Console.WriteLine(menus[4]);
                    Console.BackgroundColor = ConsoleColor.White;
                    Console.ForegroundColor = ConsoleColor.Black;
                    Console.WriteLine(menus[5]);
                    Console.BackgroundColor = ConsoleColor.Black;
                    Console.ForegroundColor = ConsoleColor.White;
                    break;
            }
        }
        static int keys()//работа менюшки
        {
            int num = 1;
            bool flag = false;
            do
            {
                Text(num);
                ConsoleKeyInfo keyPushed = Console.ReadKey();
                if (keyPushed.Key == ConsoleKey.DownArrow)
                {
                    num++;
                    Text(num);
                }
                if (keyPushed.Key == ConsoleKey.UpArrow)
                {
                    num--;
                    Text(num);
                }
                if (keyPushed.Key == ConsoleKey.Enter)
                {
                    flag = true;
                }
                if (num == 0)
                {
                    num = 5;
                    Text(5);
                }
                if (num == 6)
                {
                    num = 1;
                    Text(1);
                }
            } while (!flag);
            return num;
        }
    }
}
