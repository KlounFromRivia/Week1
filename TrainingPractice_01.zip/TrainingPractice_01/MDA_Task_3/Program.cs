﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MDA_Task_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int countTry = 1;
            string secretSMS = "Поздравляю, вы угадали пароль";
            string password = "1243";
            string vvod = "";
            Console.WriteLine("Введите пароль");
            do
            {
                vvod = Console.ReadLine();
                if (countTry == 3)
                {
                    Console.WriteLine("Вы заблокированы");
                    break;
                }
                countTry++;
            } while (vvod != password);
            if (vvod == password)
            {
                Console.WriteLine(secretSMS);
            }
            Console.ReadKey();
        }
    }
}
