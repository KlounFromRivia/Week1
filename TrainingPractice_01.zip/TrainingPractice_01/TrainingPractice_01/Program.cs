﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MDA_Task_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string exitWord = "";
            Console.WriteLine("Программа закроется, когда вы напишите слово exit");
            do
            {
                exitWord = Console.ReadLine();
            }while(exitWord.ToLower() != "exit");
            Console.WriteLine("Вы вышли из программы");
            Console.ReadKey();
        }
    }
}
